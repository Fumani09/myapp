from setuptools import setup, find_packages


setup(
    name='myapp',
    packages= find_packages(exclude = ['tests*']),
    license= 'MIT',
    author='nbjb',
    author_email='nnn',
    description='',
    long_description='',
    version='',
    url=''
)
