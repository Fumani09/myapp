def new_order(x):
    """
    Set the numbers in order from low to highest
    """
    for i in x:
        x.sort() # sorts all the numbers
    return